import tkinter as tk
import matplotlib.pyplot as plt

data_list = []


def submit_data():
    data = {
        "ФИО": entry_fio.get(),
        "Подтягивания": int(entry_pull_ups.get()),
        "Отжимания": int(entry_push_ups.get()),
        "Приседания": int(entry_squats.get()),
        "Брусья": int(entry_dips.get()),
        "Бег(км)": float(entry_running.get()),
        "Название соревнования": entry_competition.get()
    }
    data_list.append(data)

    clear_entries()


def clear_entries():
    entry_fio.delete(0, tk.END)
    entry_pull_ups.delete(0, tk.END)
    entry_push_ups.delete(0, tk.END)
    entry_squats.delete(0, tk.END)
    entry_dips.delete(0, tk.END)
    entry_running.delete(0, tk.END)
    entry_competition.delete(0, tk.END)


def plot_graph():
    fig, ax = plt.subplots()

    for data in data_list:
        fio = data["ФИО"]
        competition = data["Название соревнования"]
        pull_ups = data["Подтягивания"]
        push_ups = data["Отжимания"]
        squats = data["Приседания"]
        dips = data["Брусья"]
        running = data["Бег(км)"]

        ax.plot([pull_ups, push_ups, squats, dips, running],
                label=f"{fio} ({competition})", marker='o')

    ax.set_xlabel("Подтягивания, Отжимания, Приседания, Брусья, Бег (км)")
    ax.set_ylabel("Количество выполненных раз")
    ax.set_title("Прогресс тренировок")
    ax.legend()
    plt.xticks([1, 2, 3, 4, 5], ["Подтягивания", "Отжимания",
               "Приседания", "Брусья", "Бег (км)"], rotation=45)
    plt.show()


root = tk.Tk()
root.title("Ввод данных для построения диаграммы")

label = tk.Label(root, text="Введите данные для построения диаграммы график")
label.pack()

label_fio = tk.Label(root, text="ФИО:")
label_fio.pack()
entry_fio = tk.Entry(root)
entry_fio.pack()

label_pull_ups = tk.Label(root, text="Подтягивания:")
label_pull_ups.pack()
entry_pull_ups = tk.Entry(root)
entry_pull_ups.pack()

label_push_ups = tk.Label(root, text="Отжимания:")
label_push_ups.pack()
entry_push_ups = tk.Entry(root)
entry_push_ups.pack()

label_squats = tk.Label(root, text="Приседания:")
label_squats.pack()
entry_squats = tk.Entry(root)
entry_squats.pack()

label_dips = tk.Label(root, text="Брусья:")
label_dips.pack()
entry_dips = tk.Entry(root)
entry_dips.pack()

label_running = tk.Label(root, text="Бег (км):")
label_running.pack()
entry_running = tk.Entry(root)
entry_running.pack()

label_competition = tk.Label(root, text="Название соревнования:")
label_competition.pack()
entry_competition = tk.Entry(root)
entry_competition.pack()

submit_button = tk.Button(root, text="Отправить", command=submit_data)
submit_button.pack()

plot_button = tk.Button(root, text="Построить график", command=plot_graph)
plot_button.pack()

root.mainloop()
